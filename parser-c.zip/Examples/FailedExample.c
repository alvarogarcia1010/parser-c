int main () {
    int resultado, operador1 = 4, operador2 = 2, contador = 0;
    // Error por el punto y coma
    int arreglo[4] = {2,4,6,7};
    char caracter = 'h';
    // Parentesis de mas
    if (contador != 5)) {
        resultado = ((9 + 8) - (11*2)) % cualquierCosa;
        contador =  contador + 1;
    } else {
        int otroResultado;
        // Error de asignación
        otroResultado operador1 % operador2
    }
    return 0;
}